import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {DRACOLoader} from 'three/addons/loaders/DRACOLoader.js';
import {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/addons/postprocessing/RenderPass.js';
import {GTAOPass} from 'three/addons/postprocessing/GTAOPass.js';
import {OutputPass} from 'three/addons/postprocessing/OutputPass.js';
import {makeMaterials,applyHeroMaterials} from './materials.js';
import {createScene} from './scene.js';
const query=new URLSearchParams(location.search),study=query.get('study')||'garden';
const canvas=document.querySelector('canvas'),reduced=matchMedia('(prefers-reduced-motion: reduce)');
const stats={ready:false,frames:0,mode:study,reduced:reduced.matches,firstFrameMs:null,framesMs:[],model:null};
let renderer,camera,garden,model,composer,ao,frame=0,lost=false,points=[],baseYaw=0,yaw=0,pitch=13,distance=5,target=new THREE.Vector3(),down;
const started=performance.now();
function still(){document.documentElement.classList.remove('ready');stats.ready=false;cancelAnimationFrame(frame);frame=0;}
function scanPoints(){points=[];garden.subject.updateMatrixWorld(true);garden.subject.traverse(o=>{if(!o.isMesh||!o.visible)return;if(o.isInstancedMesh){o.geometry.computeBoundingBox();const b=o.geometry.boundingBox,m=new THREE.Matrix4();for(let i=0;i<o.count;i++){o.getMatrixAt(i,m);m.premultiply(o.matrixWorld);for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z])points.push(new THREE.Vector3(x,y,z).applyMatrix4(m));}}else{const p=o.geometry.attributes.position;for(let i=0;i<p.count;i+=2)points.push(new THREE.Vector3().fromBufferAttribute(p,i).applyMatrix4(o.matrixWorld));}});}
function setCamera(fit=true){
 const a=THREE.MathUtils.degToRad(yaw),b=THREE.MathUtils.degToRad(pitch);const front=new THREE.Vector3(Math.sin(a)*Math.cos(b),Math.sin(b),Math.cos(a)*Math.cos(b));const right=new THREE.Vector3(Math.cos(a),0,-Math.sin(a));const up=new THREE.Vector3().crossVectors(front,right);
 if(fit){
  const box=new THREE.Box3().setFromPoints(points);box.getCenter(target);target.y+=innerHeight>innerWidth?.04:.025;
  const tan=Math.tan(THREE.MathUtils.degToRad(camera.fov/2)),portrait=innerHeight>innerWidth;distance=0;
  const fillX=portrait?.91:.86,fillY=portrait?.73:.86;
  const tx=tan*camera.aspect*fillX,ty=tan*fillY;let ax=-Infinity,bx=Infinity,ay=-Infinity,by=Infinity,zmax=-Infinity;
  const q=new THREE.Vector3();for(const p of points){q.copy(p).sub(target);const z=q.dot(front),x=q.dot(right),y=q.dot(up);ax=Math.max(ax,x+tx*z);bx=Math.min(bx,x-tx*z);ay=Math.max(ay,y+ty*z);by=Math.min(by,y-ty*z);zmax=Math.max(zmax,z);}
  distance=Math.max((ax-bx)/(2*tx),(ay-by)/(2*ty),zmax+.2);target.addScaledVector(right,(ax+bx)/2).addScaledVector(up,(ay+by)/2);
 }
 const detail=query.get('detail');if(detail==='wood'){target.set(-.03,1.03,.02);distance=2.05;}else if(detail==='leaf'){target.set(-.72,1.32,.04);distance=1.4;}else if(detail==='pot'){target.set(0,.31,0);distance=2.65;}
 camera.position.copy(target).addScaledVector(front,distance);camera.lookAt(target);camera.updateMatrixWorld();
 const bounds={left:1,right:0,top:1,bottom:0},q=new THREE.Vector3();for(const p of points){q.copy(p).project(camera);const x=(q.x+1)/2,y=(1-q.y)/2;bounds.left=Math.min(bounds.left,x);bounds.right=Math.max(bounds.right,x);bounds.top=Math.min(bounds.top,y);bounds.bottom=Math.max(bounds.bottom,y);}
 stats.framing=bounds;stats.camera={yaw,pitch,distance,position:camera.position.toArray(),target:target.toArray()};
}
function render(){if(lost||document.hidden)return;const t=performance.now();renderer.info.reset();if(composer)composer.render();else renderer.render(garden.scene,camera);stats.frames++;stats.framesMs.push(performance.now()-t);if(stats.framesMs.length>120)stats.framesMs.shift();stats.drawCalls=renderer.info.render.calls;stats.triangles=renderer.info.render.triangles;if(!stats.ready){stats.firstFrameMs=performance.now()-started;stats.ready=true;document.documentElement.classList.add('ready');}}
function requestRender(){if(frame)return;frame=requestAnimationFrame(()=>{frame=0;render();});}
function resize(){camera.aspect=innerWidth/innerHeight;camera.fov=innerHeight>innerWidth?39:38;camera.updateProjectionMatrix();baseYaw=Number(query.get('yaw')??(innerHeight>innerWidth?28:0));yaw=baseYaw;pitch=Number(query.get('pitch')??13);setCamera();const pixel=Math.min(devicePixelRatio,1.6);renderer.setPixelRatio(pixel);renderer.setSize(innerWidth,innerHeight,false);if(composer){composer.setPixelRatio(pixel);composer.setSize(innerWidth,innerHeight);ao.setSize(Math.round(innerWidth*pixel*.75),Math.round(innerHeight*pixel*.75));}renderer.shadowMap.needsUpdate=true;stats.viewport=[innerWidth,innerHeight];render();}
try{
 const context=canvas.getContext('webgl2',{alpha:false,antialias:true,powerPreference:'high-performance'});if(!context)throw Error('WebGL2 unavailable');
 renderer=new THREE.WebGLRenderer({canvas,context,antialias:true});renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=study==='clay'?1.05:.95;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;renderer.shadowMap.autoUpdate=false;
 const draco=new DRACOLoader().setDecoderPath('/draco/');const loader=new GLTFLoader().setDRACOLoader(draco);model=(await loader.loadAsync('/models/hero.glb')).scene;
 if(query.get('reference')==='previous'){
  model.traverse(o=>{if(o.isMesh&&(/Continuous[_ ]aged|terminal|Canopy|shoot|twig|foliage/i.test(o.name)))o.visible=false;});
  const old=(await loader.loadAsync('/models/previous.glb')).scene;old.scale.setScalar(.70);old.position.y=.393-.53*.70;model.add(old);
 }
 draco.dispose();const mats=makeMaterials();applyHeroMaterials(model,mats,study==='clay');
 if(study==='normals')model.traverse(o=>{if(o.isMesh)o.material=new THREE.MeshNormalMaterial();});
 if(query.get('shadow')==='0')model.traverse(o=>{if(o.isMesh)o.receiveShadow=false;});
 if(query.has('bare'))model.traverse(o=>{if(/Canopy|foliage|sprays/i.test(o.name))o.visible=false;});
 garden=createScene(model,study);camera=new THREE.PerspectiveCamera(38,1,.04,60);scanPoints();renderer.info.autoReset=false;
 if(query.get('ao')==='1'){composer=new EffectComposer(renderer,new THREE.WebGLRenderTarget(1,1,{type:THREE.HalfFloatType,samples:4}));composer.addPass(new RenderPass(garden.scene,camera));ao=new GTAOPass(garden.scene,camera,1,1);ao.updateGtaoMaterial({radius:.16,distanceExponent:1.5,thickness:.08,scale:1,samples:16});ao.updatePdMaterial({radius:4,rings:2,samples:16});ao.blendIntensity=.75;composer.addPass(ao);composer.addPass(new OutputPass());stats.ambientOcclusion=true;}
 stats.model={meshes:0,vertices:0,instances:0,hasWoodMasks:false};model.traverse(o=>{if(o.isMesh){stats.model.meshes++;stats.model.vertices+=o.geometry.attributes.position.count;if(o.isInstancedMesh)stats.model.instances+=o.count;if(/Continuous[_ ]aged/.test(o.name)){stats.model.hasWoodMasks=Boolean(o.geometry.attributes.color);stats.model.woodAttributes=Object.keys(o.geometry.attributes);stats.model.woodUVRange=[Infinity,Infinity,-Infinity,-Infinity];const uv=o.geometry.attributes.uv;if(uv)for(let n=0;n<uv.count;n+=100){const r=stats.model.woodUVRange;r[0]=Math.min(r[0],uv.getX(n));r[1]=Math.min(r[1],uv.getY(n));r[2]=Math.max(r[2],uv.getX(n));r[3]=Math.max(r[3],uv.getY(n));}stats.model.woodMaterial=o.material.customProgramCacheKey();}}});
 window.__garden={stats,scene:garden.scene,subject:garden.subject,camera,renderer,render,model,setView:(azimuth,elevation=13)=>{yaw=azimuth;pitch=elevation;setCamera();render();},setKey:(p)=>{garden.key.position.set(...p);renderer.shadowMap.needsUpdate=true;render();}};
 window.addEventListener('resize',resize);reduced.addEventListener('change',()=>{stats.reduced=reduced.matches;render();});document.addEventListener('visibilitychange',()=>{if(!document.hidden)render();});
 canvas.addEventListener('pointerdown',e=>{if(reduced.matches)return;down={x:e.clientX,y:e.clientY,yaw,pitch};canvas.setPointerCapture(e.pointerId);});
 canvas.addEventListener('pointermove',e=>{if(!down||reduced.matches)return;yaw=THREE.MathUtils.clamp(down.yaw+(e.clientX-down.x)*.045,baseYaw-25,baseYaw+25);pitch=THREE.MathUtils.clamp(down.pitch+(e.clientY-down.y)*.035,7,19);setCamera(false);requestRender();});
 canvas.addEventListener('pointerup',()=>down=undefined);canvas.addEventListener('pointercancel',()=>down=undefined);
 canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();lost=true;still();});canvas.addEventListener('webglcontextrestored',()=>{lost=false;renderer.shadowMap.needsUpdate=true;render();});
 resize();
}catch(error){stats.error=error.message;still();console.warn('Static garden retained:',error.message);}
