import {spawn} from 'node:child_process';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';import {tmpdir} from 'node:os';import assert from 'node:assert/strict';
const out=process.env.QA_OUT||'qa/core';await mkdir(out,{recursive:true});
const cases=process.env.QA_CASES?JSON.parse(process.env.QA_CASES):[
 ['clay-front',1440,900,'?study=clay&yaw=0&bare=1'],['clay-left',1440,900,'?study=clay&yaw=-25&bare=1'],['clay-right',1440,900,'?study=clay&yaw=25&bare=1'],
 ['previous-clay-front',1440,900,'?study=clay&yaw=0&bare=1&reference=previous'],['previous-clay-right',1440,900,'?study=clay&yaw=25&bare=1&reference=previous'],['material-front',1440,900,'?yaw=0']];
const profile=await mkdtemp(join(tmpdir(),'bonsai-sculpt-gate-'));
const chrome=spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',['--headless','--no-first-run','--no-default-browser-check',`--user-data-dir=${profile}`,'--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','about:blank'],{stdio:['ignore','ignore','pipe']});
let stderr='',ws,next=0,session;chrome.stderr.on('data',v=>stderr+=v);
const pending=new Map(),logs=[],results=[];const pause=ms=>new Promise(r=>setTimeout(r,ms));
function send(method,params={},s){return new Promise((resolve,reject)=>{const id=++next;const timer=setTimeout(()=>{pending.delete(id);reject(Error(method+' timed out'));},25000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params,...(s?{sessionId:s}:{})}));});}
const call=(m,p={})=>send(m,p,session);
async function ev(expression){const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;}
const probe=`(()=>{const g=window.__garden;return {url:location.href,ready:g?.stats.ready||false,stats:g?.stats,text:document.body.innerText,viewport:[innerWidth,innerHeight],scroll:document.documentElement.scrollWidth>innerWidth||document.documentElement.scrollHeight>innerHeight,programs:g?.renderer.info.programs?.map(p=>p.diagnostics?{runnable:p.diagnostics.runnable,log:p.diagnostics.programLog}:null),userAgent:navigator.userAgent}})()`;
try{
 let info;for(let n=0;n<120;n++){try{info=await readFile(join(profile,'DevToolsActivePort'),'utf8');break;}catch{await pause(100);}}assert.ok(info,'Chrome started');
 const [port,path]=info.trim().split('\n');ws=new WebSocket(`ws://127.0.0.1:${port}${path}`);await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j;});
 ws.onmessage=({data})=>{const m=JSON.parse(data),p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}else if(m.method==='Runtime.exceptionThrown'||m.method==='Log.entryAdded'||(m.method==='Runtime.consoleAPICalled'&&['error','warning'].includes(m.params.type)))logs.push(m);};
 const {targetId}=await send('Target.createTarget',{url:'about:blank'});({sessionId:session}=await send('Target.attachToTarget',{targetId,flatten:true}));for(const x of ['Runtime','Page','Log'])await call(x+'.enable');
 await call('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'reduce'}]});
 for(const [name,w,h,query]of cases){
  await call('Emulation.setDeviceMetricsOverride',{width:w,height:h,deviceScaleFactor:Number(process.env.QA_DPR||1),mobile:false});
  const u=new URL((process.env.QA_URL||'http://127.0.0.1:5188/')+query);u.searchParams.set('qa',name);await call('Page.navigate',{url:u.href});
  let state;for(let n=0;n<200;n++){try{state=await ev(probe);if(state.ready&&state.url===u.href)break;}catch{}await pause(100);}
  assert.equal(state?.ready,true,JSON.stringify(state));await pause(250);state=await ev(probe);assert.equal(state.text,'');assert.equal(state.scroll,false);
  const shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false,clip:{x:0,y:0,width:w,height:h,scale:1}});await writeFile(join(out,name+'.png'),Buffer.from(shot.data,'base64'));
  results.push({name,...state});console.log(JSON.stringify({name,framing:state.stats.framing,model:state.stats.model,triangles:state.stats.triangles,programs:state.programs}));
 }
 assert.equal(logs.filter(x=>x.method==='Runtime.exceptionThrown').length,0);
}finally{await writeFile(join(out,'results.json'),JSON.stringify({results,logs},null,2));if(ws)ws.close();chrome.kill('SIGTERM');await writeFile(join(out,'chrome.log'),stderr);}
